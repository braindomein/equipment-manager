var sessionId;
var sessionDataObject;
var html = '';
var userRoleLoggedIn;

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
        userRoleLoggedIn = sessionDataObject.user.userRole;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
        loadRecords();
    }
    ;
}

function getQueryParameter(parameterName) {
    var queryString = window.top.location.search.substring(1);
    var parameterName = parameterName + "=";
    if (queryString.length > 0) {
        begin = queryString.indexOf(parameterName);
        if (begin !== -1) {
            begin += parameterName.length;
            end = queryString.indexOf("&", begin);
            if (end === -1) {
                end = queryString.length
            }
            return unescape(queryString.substring(begin, end));
        }
    }
    return null;
}

function loadRecords() {
    var url = '';

    if (userRoleLoggedIn === 'ADMINISTRATOR') {
//        /getAllFaultRecords/{session}
        url = '/service/getAllFaultRecords/' + sessionId;
    } else if (userRoleLoggedIn === 'MAINTAINER') {
//        /getMaintainerFaultRecords/{session}
        url = '/service/getMaintainerFaultRecords/' + sessionId;
    } else if (userRoleLoggedIn === 'EMPLOYEE') {
//        /getEmployeeFaultRecords/{session}
        url = '/service/getEmployeeFaultRecords/' + sessionId;
    }

    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            console.log(data);
            $.each(data, function (index, item) {
                html += '<tr>';
                html += '   <td>' + unescape(item.id) + '</td>';
                html += '   <td>' + unescape(item.fault.id) + '</td>';
                html += '   <td>' + unescape(item.comments) + '</td>';
                html += '   <td>' + unescape(item.status) + '</td>';
                html += '   <td>' + unescape(item.cost) + '</td>';
                html += '   <td>' + unescape(item.dateRepaired) + '</td>';
                html += '   <td class="td-actions">';
                html += '       <a href="#" onclick="setSelectedItemId(' + item.id + ');" data-toggle="modal" data-target="#viewRecordModal" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>';
                html += '       <a href="#" onclick="setSelectedItemId(' + item.id + ');" data-toggle="modal" data-target="#editRecordModal" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>';
                html += '       <a href="#" onclick="setDeletedRecordId(' + item.id + ');" data-toggle="modal" data-target="#deleteRecordId" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>';
                html += '   </td>';
                html += '</tr>';
            });
            $('#recordsListHolderId').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

var selectedItem = '';
function setSelectedItemId(itemId) {
    console.log("Selected Id: " + selectedItem);
    selectedItem = itemId;
    loadSelectedItemInfo();
}

function loadSelectedItemInfo() {
    // /getFaultRecord/{session}/{id}
    var url = '/service/getFaultRecord/' + sessionId + '/' + selectedItem;
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            console.log(data);
            $('#faultHolderId').html(data.fault.id);
            $('#commentsHolderId').html(data.comments);
            $('#statusHolderId').html(data.status);
            $('#costHolderId').html(data.cost);
            $('#dateRepaired').html(data.dateRepaired);

            $('#faultHolderId1').html('<input id="id" class="form-control col-md-7 col-xs-12" name="id" required="required" type="hidden" value="' + data.id + '"><input id="name" class="form-control col-md-7 col-xs-12" name="name" disabled="" required="required" type="text" value="' + data.fault.id + '">');
            $('#commentsHolderId1').html('<input id="comments" class="form-control col-md-7 col-xs-12" name="comments" required="required" type="text" value="' + data.comments + '">');
            $('#statusHolderId1').html('<input id="status" class="form-control col-md-7 col-xs-12" name="status" required="required" type="text" value="' + data.status + '">');
            $('#costHolderId1').html('<input id="cost" class="form-control col-md-7 col-xs-12" name="cost" required="required" type="number" value="' + data.cost + '">');
            $('#dateRepaired1').html('<input id="dateRepaired3" class="form-control col-md-7 col-xs-12" name="dateRepaired3" required="required" type="datetime-local" value="' + data.dateRepaired + '">');

        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record information'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record information'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

var recordId = '';
function setDeletedRecordId(record) {
    recordId = record;
}
function deleteRecord() {
    // /deleteFaultRecord/{session}/{id}
    var url = '/service/deleteFaultRecord/' + sessionId + '/' + recordId;
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        contentType: "application/json",
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record deleted successful.'
            }, {
                type: 'success'
            });
            window.location = "all_fault_records.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record cannot be deleted.'
            }, {
                type: 'danger'
            });
        }
    });
}

function updateFunction() {

    var id = document.getElementById("id").value;
    var comments = document.getElementById("comments").value;
    var status = document.getElementById("status").value;
    var cost = document.getElementById("cost").value;
    var dateRepaired = document.getElementById("dateRepaired3").value;

    var encodeId = encodeURIComponent(id);
    var encodeComments = encodeURIComponent(comments);
    var encodeStatus = encodeURIComponent(status);
    var encodeCost = encodeURIComponent(cost);
    var encodeDateRepaired = encodeURIComponent(dateRepaired);


    if (encodeId === '' || encodeComments === '' || encodeStatus === '' || encodeCost === '' || encodeDateRepaired === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /updateFaultRecord/{session}/{id}/{comments}/{status}/{cost}/{dateRepaired}
        var url = '/service/updateFaultRecord/'
                + sessionId + '/'
                + encodeId + '/'
                + encodeComments + '/'
                + encodeStatus + '/'
                + encodeCost + '/'
                + encodeDateRepaired;

    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record updated to the database '
            }, {
                type: 'success'
            });

            window.location = "all_fault_records.html";
        },
        error: function (data, status) {

            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record was not updated.'
            }, {
                type: 'danger'
            });
        }
    });
}