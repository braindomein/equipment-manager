var sessionId;
var sessionDataObject;
var html = '';

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
        loadRecords();
    }
    ;
}

function getQueryParameter(parameterName) {
    var queryString = window.top.location.search.substring(1);
    var parameterName = parameterName + "=";
    if (queryString.length > 0) {
        begin = queryString.indexOf(parameterName);
        if (begin !== -1) {
            begin += parameterName.length;
            end = queryString.indexOf("&", begin);
            if (end === -1) {
                end = queryString.length
            }
            return unescape(queryString.substring(begin, end));
        }
    }
    return null;
}

function loadRecords() {
    // /getAllEmployees/{session}
    var url = '/service/getAllEmployees/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.each(data, function (index, item) {
                console.log(data);
                html += '<tr>';
                html += '   <td>' + unescape(item.id) + '</td>';
                html += '   <td>' + unescape(item.department.name) + '</td>';
                html += '   <td>' + unescape(item.fullnames) + '</td>';
                if (item.gender === true) {
                    html += '   <td>M</td>';
                } else if (item.gender === false) {
                    html += '   <td>F</td>';
                }
                html += '   <td>' + unescape(item.email) + '</td>';
                html += '   <td class="td-actions">';
                html += '       <a href="#" onclick="setSelectedItemId(' + item.id + ');" data-toggle="modal" data-target="#viewRecordModal" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>';
                html += '       <a href="#" onclick="setSelectedItemId(' + item.id + ');" data-toggle="modal" data-target="#editRecordModal" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>';
                html += '       <a href="#" onclick="setDeletedRecordId(' + item.id + ');" data-toggle="modal" data-target="#deleteRecordId" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>';
                html += '   </td>';
                html += '</tr>';
            });
            $('#recordsListHolderId').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}


var selectedItem = '';
function setSelectedItemId(itemId) {
    console.log("Selected Id: " + selectedItem);
    selectedItem = itemId;
    loadSelectedItemInfo();
}

function loadSelectedItemInfo() {
    // /getEmployee/{session}/{id}
    var url = '/service/getEmployee/' + sessionId + '/' + selectedItem;
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            console.log(data);
            $('#fullnamesHolderId').html(data.fullnames);
            $('#identificationNoHolderId').html(data.identificationNo);
            $('#cellPhoneHolderId').html(data.cellPhone);
            $('#emailHolderId').html(data.email);
            $('#genderHolderId').html(data.gender);
            $('#relationshipStatusHolderId').html(data.relationshipStatus);
            $('#userHolderId').html(data.user.username);
            $('#departmentHolderId').html(data.department.name);

            $('#fullnamesHolderId3').html('<input id="id3" class="form-control col-md-7 col-xs-12" name="id3" required="required" type="hidden" value="' + data.id + '"><input id="fullnames3" class="form-control col-md-7 col-xs-12" name="fullnames3" required="required" type="text" value="' + data.fullnames + '">');
            $('#identificationNoHolderId3').html('<input id="identificationNo3" class="form-control col-md-7 col-xs-12" name="identificationNo3" required="required" type="text" value="' + data.identificationNo + '">');
            $('#cellPhoneHolderId3').html('<input id="cellPhone3" class="form-control col-md-7 col-xs-12" name="cellPhone3" required="required" type="text" value="' + data.cellPhone + '">');
            $('#emailHolderId3').html('<input id="email3" class="form-control col-md-7 col-xs-12" name="email3" required="required" type="text" value="' + data.email + '">');
            $('#userHolderId3').html('<input id="gender3" class="form-control col-md-7 col-xs-12" name="gender3" required="required" type="hidden" value="' + data.gender + '">\n\
<input id="relationshipStatus3" class="form-control col-md-7 col-xs-12" name="relationshipStatus3" required="required" type="hidden" value="' + data.relationshipStatus + '">\n\
<input id="username3" class="form-control col-md-7 col-xs-12" name="username3" disabled="" required="required" type="text" value="' + data.user.username + '">');
            $('#departmentHolderId3').html('<input id="userRole3" class="form-control col-md-7 col-xs-12" name="userRole3" required="required" type="hidden" value="' + data.user.userRole + '"><input disabled="" id="department3" class="form-control col-md-7 col-xs-12" name="department3" required="required" type="text" value="' + data.department.name + '">');

        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record information'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record information'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

var recordId = '';
function setDeletedRecordId(record) {
    recordId = record;
}
function deleteRecord() {
    // /deleteEmployee/{session}/{id}
    var url = '/service/deleteEmployee/' + sessionId + '/' + recordId;
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        contentType: "application/json",
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record deleted successful.'
            }, {
                type: 'success'
            });
            window.location = "all_employees.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record cannot be deleted.'
            }, {
                type: 'danger'
            });
        }
    });
}

function updateFunction() {

    var id = document.getElementById("id3").value;
    var fullnames = document.getElementById("fullnames3").value;
    var identificationNo = document.getElementById("identificationNo3").value;
    var cellPhone = document.getElementById("cellPhone3").value;
    var email = document.getElementById("email3").value;
    var gender = document.getElementById("gender3").value;
    var relationshipStatus = document.getElementById("relationshipStatus3").value;
    var userRole = document.getElementById("userRole3").value;

    var encodeId = encodeURIComponent(id);
    var encodeFullnames = encodeURIComponent(fullnames);
    var encodeIdentificationNo = encodeURIComponent(identificationNo);
    var encodeCellPhone = encodeURIComponent(cellPhone);
    var encodeEmail = encodeURIComponent(email);
    var encodeGender = encodeURIComponent(gender);
    var encodeRelationshipStatus = encodeURIComponent(relationshipStatus);
    var encodeUserRole = encodeURIComponent(userRole);


    if (encodeId === '' || encodeFullnames === '' || encodeIdentificationNo === '' ||
            encodeCellPhone === '' || encodeEmail === '' || encodeGender === ''
            || encodeRelationshipStatus === '' || encodeUserRole === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /updateStaff/{session}/{id}/{fullnames}/{identificationNo}/{cellPhone}/{email}/{gender}/{relationshipStatus}/{userRole}
        var url = '/service/updateStaff/'
                + sessionId + '/'
                + encodeId + '/'
                + encodeFullnames + '/'
                + encodeIdentificationNo + '/'
                + encodeCellPhone + '/'
                + encodeEmail + '/'
                + encodeGender + '/'
                + encodeRelationshipStatus + '/'
                + encodeUserRole;

    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record updated to the database '
            }, {
                type: 'success'
            });

            window.location = "all_employees.html";
        },
        error: function (data, status) {

            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record was not updated.'
            }, {
                type: 'danger'
            });
        }
    });
}