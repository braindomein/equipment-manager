var sessionId;
var sessionDataObject;
var html = '';

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
        loadOrganisationsCount();
        loadDepartmentsCount();
        loadEquipmentsCount();
        loadFaultsCount();
        loadUsersCount();
        loadMaintainerFaultsCount()
        loadSubmittedFaultsCount();
    }
    ;
}

function loadOrganisationsCount() {
    // /getAllOrganisations/{session}
    var url = '/service/getAllOrganisations/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $('#organisationsCountId').html(data.length);
        },
        error: function (data, status) {

        }
    });
}

function loadDepartmentsCount() {
    // /getAllDepartments/{session}
    var url = '/service/getAllDepartments/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $('#departmentsCountId').html(data.length);
        },
        error: function (data, status) {

        }
    });
}

function loadEquipmentsCount() {
    // /getAllEquipments/{session}
    var url = '/service/getAllEquipments/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $('#equipmentsCountId').html(data.length);
        },
        error: function (data, status) {

        }
    });
}

function loadFaultsCount() {
    // /getAllFaults/{session}
    var url = '/service/getAllFaults/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $('#faultsCountId').html(data.length);
        },
        error: function (data, status) {

        }
    });
}

function loadUsersCount() {
    // /getAllUsers/{session}
    var url = '/service/getAllUsers/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $('#usersCountId').html(data.length);
        },
        error: function (data, status) {

        }
    });
}

function loadMaintainerFaultsCount() {
    // /getAllMaintainerFaults/{session}
    var url = '/service/getAllMaintainerFaults/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $('#maintainerFaultsCountId').html(data.length);
        },
        error: function (data, status) {

        }
    });
}

function loadSubmittedFaultsCount() {
    // /getAllSubmittedFaults/{session}
    var url = '/service/getAllSubmittedFaults/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $('#submittedFaultsCountId').html(data.length);
        },
        error: function (data, status) {

        }
    });
}