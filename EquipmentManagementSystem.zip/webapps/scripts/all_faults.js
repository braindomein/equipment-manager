var sessionId;
var sessionDataObject;
var html = '';
var userRoleLoggedIn;

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
        userRoleLoggedIn = sessionDataObject.user.userRole;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
        loadRecords();
        loadMaintainers();
    }
    ;
}

function getQueryParameter(parameterName) {
    var queryString = window.top.location.search.substring(1);
    var parameterName = parameterName + "=";
    if (queryString.length > 0) {
        begin = queryString.indexOf(parameterName);
        if (begin !== -1) {
            begin += parameterName.length;
            end = queryString.indexOf("&", begin);
            if (end === -1) {
                end = queryString.length
            }
            return unescape(queryString.substring(begin, end));
        }
    }
    return null;
}

function loadRecords() {
    var url = '';

    if (userRoleLoggedIn === 'ADMINISTRATOR') {
//        /getAllFaults/{session}
        url = '/service/getAllFaults/' + sessionId;
    } else if (userRoleLoggedIn === 'MAINTAINER') {
//        /getAllAssignedFaults/{session}
        url = '/service/getAllAssignedFaults/' + sessionId;
    } else if (userRoleLoggedIn === 'EMPLOYEE') {
//        /getAllSubmittedFaults/{session}
        url = '/service/getAllSubmittedFaults/' + sessionId;
    }

    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.each(data, function (index, item) {
                console.log(data);
                html += '<tr>';
                html += '   <td>' + unescape(item.id) + '</td>';
                html += '   <td>' + unescape(item.dateReported) + '</td>';
                html += '   <td>' + unescape(item.employee.fullnames) + '</td>';
                html += '   <td>' + unescape(item.equipment.serialNo) + '</td>';
                html += '   <td>' + unescape(item.comments) + '</td>';
                html += '   <td>' + unescape(item.priority) + '</td>';
                if (item.assigned === true) {
                    html += '   <td>Yes</td>';
                } else if (item.assigned === false) {
                    html += '   <td>No</td>';
                }
                html += '   <td class="td-actions">';
                html += '       <a href="#" onclick="setSelectedItemId(' + item.id + ');" data-toggle="modal" data-target="#assignFaultModal"  class="btn btn-success btn-xs"><i class="fa fa-user"></i> Assign </a>';
                html += '       <a href="#" onclick="setSelectedItemId(' + item.id + ');" data-toggle="modal" data-target="#viewRecordModal" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>';
                html += '       <a href="#" onclick="setSelectedItemId(' + item.id + ');" data-toggle="modal" data-target="#editRecordModal" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>';
                html += '       <a href="#" onclick="setDeletedRecordId(' + item.id + ');" data-toggle="modal" data-target="#deleteRecordId" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>';
                html += '   </td>';
                html += '</tr>';
            });
            $('#recordsListHolderId').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

var selectedItem = '';
function setSelectedItemId(itemId) {
    console.log("Selected Id: " + selectedItem);
    selectedItem = itemId;
    loadSelectedItemInfo();
}

function loadSelectedItemInfo() {
    // /getFault/{session}/{id}
    var url = '/service/getFault/' + sessionId + '/' + selectedItem;
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            console.log(data);
            $('#employeeHolderId3').html(data.employee.fullnames);
            $('#equipmentHolderId3').html(data.equipment.name);
            $('#commentsHolderId').html(data.comments);
            $('#priorityHolderId').html(data.priority);
            $('#dateReportedHolderId').html(data.dateReported);
            $('#assignedHolderId').html(data.assigned);

            $('#employeeHolderId1').html('<input id="id" class="form-control col-md-7 col-xs-12" name="id" required="required" type="hidden" value="' + data.id + '"><input id="employee1" class="form-control col-md-7 col-xs-12" name="employee1" disabled="" required="required" type="text" value="' + data.employee.fullnames + '">');
            $('#equipmentHolderId1').html('<input id="equipment1" class="form-control col-md-7 col-xs-12" name="equipment1" required="required" disabled="" type="text" value="' + data.equipment.name + '">');
            $('#commentsHolderId1').html('<input id="comments" class="form-control col-md-7 col-xs-12" name="comments" required="required" type="text" value="' + data.comments + '">');
            $('#priorityHolderId1').html('<input id="priority" class="form-control col-md-7 col-xs-12" name="priority" required="required" disabled="" type="text" value="' + data.priority + '">');
            $('#dateReportedHolderId1').html('<input id="dateReported" class="form-control col-md-7 col-xs-12" name="dateReported" required="required" disabled="" type="text" value="' + data.dateReported + '">');
            $('#assignedHolderId1').html('<input id="assigned" class="form-control col-md-7 col-xs-12" name="assigned" required="required" disabled="" type="text" value="' + data.assigned + '">');

        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record information'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record information'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

var recordId = '';
function setDeletedRecordId(record) {
    recordId = record;
}
function deleteRecord() {
    // /deleteFault/{session}/{id}
    var url = '/service/deleteFault/' + sessionId + '/' + recordId;
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        contentType: "application/json",
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record deleted successful.'
            }, {
                type: 'success'
            });
            window.location = "all_faults.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record cannot be deleted.'
            }, {
                type: 'danger'
            });
        }
    });
}

function updateFunction() {

    var id = document.getElementById("id").value;
    var comments = document.getElementById("comments").value;

    var encodeId = encodeURIComponent(id);
    var encodeComments = encodeURIComponent(comments);


    if (encodeId === '' || encodeComments === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /updateFault/{session}/{id}/{comments}
        var url = '/service/updateFault/'
                + sessionId + '/'
                + encodeId + '/'
                + encodeComments;

    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record updated to the database '
            }, {
                type: 'success'
            });

            window.location = "all_faults.html";
        },
        error: function (data, status) {

            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record was not updated.'
            }, {
                type: 'danger'
            });
        }
    });
}

function loadMaintainers() {
    // /getAllMaintainers/{session}
    var url = '/service/getAllMaintainers/' + sessionId;
    var html = '';
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            html += '<option disabled="" selected="">- Select Maintainer -</option>';
            $.each(data, function (index, item) {
                html += '<option value="' + unescape(item.id) + '">' + unescape(item.fullnames) + '</option>';
            });
            $('#maintainer').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

function assignFault() {
//    /addMaintainerFault/{session}/{fault}/{maintainer}
    var id = document.getElementById("id").value;
    var maintainer = document.getElementById("maintainer").value;

    var encodeId = encodeURIComponent(id);
    var encodeMaintainer = encodeURIComponent(maintainer);


    if (encodeId === '' || encodeMaintainer === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /addMaintainerFault/{session}/{fault}/{maintainer}
        var url = '/service/addMaintainerFault/' + sessionId + '/' + encodeId + '/' + encodeMaintainer;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record  was added to the database '
            }, {
                type: 'success'
            });
            window.location = "all_faults.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record  was not added to the database '
            }, {
                type: 'danger'
            });

            console.log(data);
        }
    });
}