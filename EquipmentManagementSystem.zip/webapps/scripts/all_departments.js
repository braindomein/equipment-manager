var sessionId;
var sessionDataObject;
var html = '';

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
        loadRecords();
    }
    ;
}

function getQueryParameter(parameterName) {
    var queryString = window.top.location.search.substring(1);
    var parameterName = parameterName + "=";
    if (queryString.length > 0) {
        begin = queryString.indexOf(parameterName);
        if (begin !== -1) {
            begin += parameterName.length;
            end = queryString.indexOf("&", begin);
            if (end === -1) {
                end = queryString.length
            }
            return unescape(queryString.substring(begin, end));
        }
    }
    return null;
}

function loadRecords() {
    // /getAllDepartments/{session}
    var url = '/service/getAllDepartments/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.each(data, function (index, item) {
                console.log(data);
                html += '<tr>';
                html += '   <td>' + unescape(item.id) + '</td>';
                html += '   <td>' + unescape(item.name) + '</td>';
                html += '   <td>' + unescape(item.organisation.name) + '</td>';
                html += '   <td class="td-actions">';
                html += '       <a href="#" onclick="setSelectedItemId(' + item.id + ');" data-toggle="modal" data-target="#viewRecordModal" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>';
                html += '       <a href="#" onclick="setSelectedItemId(' + item.id + ');" data-toggle="modal" data-target="#editRecordModal" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>';
                html += '       <a href="#" onclick="setDeletedRecordId(' + item.id + ');" data-toggle="modal" data-target="#deleteRecordId" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>';
                html += '   </td>';
                html += '</tr>';
            });
            $('#recordsListHolderId').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

var selectedItem = '';
function setSelectedItemId(itemId) {
    console.log("Selected Id: " + selectedItem);
    selectedItem = itemId;
    loadSelectedItemInfo();
}

function loadSelectedItemInfo() {
    // /getDepartment/{session}/{id}
    var url = '/service/getDepartment/' + sessionId + '/' + selectedItem;
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            console.log(data);
            $('#orgNameHolderId1').html('<input id="id" class="form-control col-md-7 col-xs-12" name="id" required="required" type="hidden" value="' + data.id + '"><input id="name" class="form-control col-md-7 col-xs-12" name="name" required="required" type="text" value="' + data.name + '">');
            $('#orgOrganisationHolderId1').html('<input id="organisation" class="form-control col-md-7 col-xs-12" name="organisation" required="required" disabled="" type="text" value="' + data.organisation.name + '">');
            $('#orgNameHolderId').html(data.name);
            $('#orgOrganisationHolderId').html(data.organisation.name);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record information'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record information'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

var recordId = '';
function setDeletedRecordId(record) {
    recordId = record;
}
function deleteRecord() {
    // /deleteDepartment/{session}/{id}
    var url = '/service/deleteDepartment/' + sessionId + '/' + recordId;
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        contentType: "application/json",
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record deleted successful.'
            }, {
                type: 'success'
            });
            window.location = "all_departments.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record cannot be deleted.'
            }, {
                type: 'danger'
            });
        }
    });
}

function updateFunction() {

    var id = document.getElementById("id").value;
    var name = document.getElementById("name").value;

    var encodeId = encodeURIComponent(id);
    var encodeName = encodeURIComponent(name);


    if (encodeId === '' || encodeName === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /updateDepartment/{session}/{id}/{name}
        var url = '/service/updateDepartment/'
                + sessionId + '/'
                + encodeId + '/'
                + encodeName;

    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record updated to the database '
            }, {
                type: 'success'
            });

            window.location = "all_departments.html";
        },
        error: function (data, status) {

            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record was not updated.'
            }, {
                type: 'danger'
            });
        }
    });
}