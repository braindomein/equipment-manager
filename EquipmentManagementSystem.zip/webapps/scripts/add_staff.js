var sessionId;
var sessionDataObject;
var html = '';

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
        loadDepartments();
        $('#personalInfo').hide();
    }
    ;
}

function getQueryParameter(parameterName) {
    var queryString = window.top.location.search.substring(1);
    var parameterName = parameterName + "=";
    if (queryString.length > 0) {
        begin = queryString.indexOf(parameterName);
        if (begin !== -1) {
            begin += parameterName.length;
            end = queryString.indexOf("&", begin);
            if (end === -1) {
                end = queryString.length
            }
            return unescape(queryString.substring(begin, end));
        }
    }
    return null;
}

function loadDepartments() {
    // /getAllDepartments/{session}
    var url = '/service/getAllDepartments/' + sessionId;
    var html = '';
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            html += '<option disabled="" selected="">- Select Department -</option>';
            $.each(data, function (index, item) {
                html += '<option value="' + unescape(item.id) + '">' + unescape(item.name) + '</option>';
            });
            $('#department').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

function addRecordFunction() {
//    /addStaff/{session}/{fullnames}/{identificationNo}/{cellPhone}/{email}/{gender}/{relationshipStatus}}/{username}/{password}/{userRole}/{department}
    var fullnames = document.getElementById("fullnames").value;
    var identificationNo = document.getElementById("identificationNo").value;
    var cellPhone = document.getElementById("cellPhone").value;
    var email = document.getElementById("email").value;
    var gender = document.getElementById("gender").value;
    var relationshipStatus = document.getElementById("relationshipStatus").value;
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var password2 = document.getElementById("password2").value;
    var userRole = document.getElementById("userRole").value;
    var department = document.getElementById("department").value;

    var encodeFullnames = encodeURIComponent(fullnames);
    var encodeIdentificationNo = encodeURIComponent(identificationNo);
    var encodeCellPhone = encodeURIComponent(cellPhone);
    var encodeEmail = encodeURIComponent(email);
    var encodeGender = encodeURIComponent(gender);
    var encodeRelationshipStatus = encodeURIComponent(relationshipStatus);
    var encodeUsername = encodeURIComponent(username);
    var encodePassword = encodeURIComponent(password);
    var encodePassword2 = encodeURIComponent(password2);
    var encodeUserRole = encodeURIComponent(userRole);
    var encodeDepartment = encodeURIComponent(department);


    if (encodeFullnames === '' || encodeIdentificationNo === '' || encodeCellPhone === '' || encodeEmail === ''
            || encodeGender === '' || encodeRelationshipStatus === '' || encodeUsername === '' || encodePassword === ''
            || encodePassword2 === '' || encodeUserRole === '' || encodeDepartment === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else if (encodePassword !== encodePassword2) {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Passwords do not match. Please check to confirm!'
        }, {
            type: 'danger'
        });


    } else
        // /addStaff/{session}/{fullnames}/{identificationNo}/{cellPhone}/{email}/{gender}/{relationshipStatus}}/{username}/{password}/{userRole}/{department}
        var url = '/service/addStaff/' + sessionId + '/' + encodeFullnames + '/' + encodeIdentificationNo + '/' + encodeCellPhone
                + '/' + encodeEmail + '/' + encodeGender + '/' + encodeRelationshipStatus + '/' + encodeUsername + '/' + encodePassword
                + '/' + encodeUserRole + '/' + encodeDepartment;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record  was added to the database '
            }, {
                type: 'success'
            });

            if (userRole === 'MAINTAINER') {
                window.location = "all_maintainers.html";
            } else if (userRole === 'EMPLOYEE') {
                window.location = "all_employees.html";
            }

        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record  was not added to the database '
            }, {
                type: 'danger'
            });

            console.log(data);
        }
    });
}

function showPersonalInfo() {
    $('#personalInfo').show();
}