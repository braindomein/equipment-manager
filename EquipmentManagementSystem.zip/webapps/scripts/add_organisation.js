var sessionId;
var sessionDataObject;
var html = '';

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
    }
    ;
}

function getQueryParameter(parameterName) {
    var queryString = window.top.location.search.substring(1);
    var parameterName = parameterName + "=";
    if (queryString.length > 0) {
        begin = queryString.indexOf(parameterName);
        if (begin !== -1) {
            begin += parameterName.length;
            end = queryString.indexOf("&", begin);
            if (end === -1) {
                end = queryString.length
            }
            return unescape(queryString.substring(begin, end));
        }
    }
    return null;
}

function addRecordFunction() {
//    /addOrganisation/{session}/{name}/{location}
    var name = document.getElementById("name").value;
    var location = document.getElementById("location").value;

    var encodeName = encodeURIComponent(name);
    var encodeLocation = encodeURIComponent(location);

    if (encodeName === '' || encodeLocation === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /addOrganisation/{session}/{name}/{location}
        var url = '/service/addOrganisation/' + sessionId + '/' + encodeName + '/' + encodeLocation;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record  was added to the database '
            }, {
                type: 'success'
            });
            window.location = "all_organisations.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record  was not added to the database '
            }, {
                type: 'danger'
            });

            console.log(data);
        }
    });
}