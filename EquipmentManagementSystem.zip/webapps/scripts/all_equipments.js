var sessionId;
var sessionDataObject;
var html = '';

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
        loadRecords();
        loadDepartments();
    }
    ;
}

function getQueryParameter(parameterName) {
    var queryString = window.top.location.search.substring(1);
    var parameterName = parameterName + "=";
    if (queryString.length > 0) {
        begin = queryString.indexOf(parameterName);
        if (begin !== -1) {
            begin += parameterName.length;
            end = queryString.indexOf("&", begin);
            if (end === -1) {
                end = queryString.length
            }
            return unescape(queryString.substring(begin, end));
        }
    }
    return null;
}

function loadRecords() {
    // /getAllEquipments/{session}
    var url = '/service/getAllEquipments/' + sessionId;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.each(data, function (index, item) {
                console.log(data);
                html += '<tr>';
                html += '   <td>' + unescape(item.id) + '</td>';
                html += '   <td>' + unescape(item.serialNo) + '</td>';
                html += '   <td>' + unescape(item.name) + '</td>';
                html += '   <td>' + unescape(item.equipmentType) + '</td>';
                if (item.condition === true) {
                    html += '   <td>New</td>';
                } else if (item.condition === false) {
                    html += '   <td>Old</td>';
                }
                html += '   <td>' + unescape(item.quantity) + '</td>';
                html += '   <td class="td-actions">';
                html += '       <a id="distributeLink" href="#" onclick="setSelectedItemId(' + item.id + ');" data-toggle="modal" data-target="#distributeModal"  class="btn btn-success btn-xs"><i class="fa fa-exchange"></i> Distribute </a>';
                html += '       <a id="stockLink" href="#" onclick="setSelectedItemId(' + item.id + ');" data-toggle="modal" data-target="#stockModal"  class="btn btn-warning btn-xs"><i class="fa fa-plus"></i> Stock </a>';
                html += '       <a id="viewEquipmentLink" href="#" onclick="setSelectedItemId(' + item.id + ');" data-toggle="modal" data-target="#viewRecordModal" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>';
                html += '       <a id="editEquipmentLink" href="#" onclick="setSelectedItemId(' + item.id + ');" data-toggle="modal" data-target="#editRecordModal" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>';
//                html += '       <a href="#" onclick="setDeletedRecordId(' + item.id + ');" data-toggle="modal" data-target="#deleteRecordId" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a>';
                html += '   </td>';
                html += '</tr>';
            });
            $('#recordsListHolderId').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

var selectedItem = '';
function setSelectedItemId(itemId) {
    console.log("Selected Id: " + selectedItem);
    selectedItem = itemId;
    loadSelectedItemInfo();
}

function loadSelectedItemInfo() {
    // /getEquipment/{session}/{id}
    var url = '/service/getEquipment/' + sessionId + '/' + selectedItem;
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            console.log(data);
            $('#serialNoHolderId').html(data.serialNo);
            $('#nameHolderId').html(data.name);
            $('#equipmentTypeHolderId').html(data.equipmentType);
            $('#quantityHolderId').html(data.quantity);

            $('#equipmentHolderId').html('<input id="id2" class="form-control col-md-7 col-xs-12" name="id2" required="required" type="hidden" value="' + data.id + '"><input id="serialNo" disabled="" class="form-control col-md-7 col-xs-12" name="serialNo" required="required" type="text" value="' + data.serialNo + '">');
            $('#equipmentHolderId2').html('<input id="id3" class="form-control col-md-7 col-xs-12" name="id3" required="required" type="hidden" value="' + data.id + '"><input id="serialNo" disabled="" class="form-control col-md-7 col-xs-12" name="serialNo" required="required" type="text" value="' + data.serialNo + '">');
            $('#serialNoHolderId2').html('<input id="id" class="form-control col-md-7 col-xs-12" name="id" required="required" type="hidden" value="' + data.id + '"><input id="serialNo" class="form-control col-md-7 col-xs-12" name="serialNo" required="required" type="text" value="' + data.serialNo + '">');
            $('#nameHolderId2').html('<input id="name" class="form-control col-md-7 col-xs-12" name="name" required="required" type="text" value="' + data.name + '">');
            $('#equipmentTypeHolderId2').html('<input id="equipmentType" disabled="" class="form-control col-md-7 col-xs-12" name="equipmentType" required="required" type="text" value="' + data.equipmentType + '">');
            $('#quantityHolderId2').html('<input id="condition" class="form-control col-md-7 col-xs-12" name="condition" required="required" type="hidden" value="' + data.condition + '"><input id="quantity3" class="form-control col-md-7 col-xs-12" name="quantity3" required="required" type="number" value="' + data.quantity + '">');

        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record information'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record information'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

var recordId = '';
function setDeletedRecordId(record) {
    recordId = record;
}
function deleteRecord() {
    // /deleteEquipment/{session}/{id}
    var url = '/service/deleteEquipment/' + sessionId + '/' + recordId;
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        contentType: "application/json",
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record deleted successful.'
            }, {
                type: 'success'
            });
            window.location = "all_equipments.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record cannot be deleted.'
            }, {
                type: 'danger'
            });
        }
    });
}

function updateFunction() {

    var id = document.getElementById("id").value;
    var serialNo = document.getElementById("serialNo").value;
    var name = document.getElementById("name").value;
    var equipmentType = document.getElementById("equipmentType").value;
    var quantity = document.getElementById("quantity3").value;
    var condition = document.getElementById("condition").value;

    var encodeId = encodeURIComponent(id);
    var encodeSerialNo = encodeURIComponent(serialNo);
    var encodeName = encodeURIComponent(name);
    var encodeEquipmentType = encodeURIComponent(equipmentType);
    var encodeQuantity = encodeURIComponent(quantity);
    var encodeCondition = encodeURIComponent(condition);


    if (encodeId === '' || encodeSerialNo === '' || encodeName === '' || encodeEquipmentType === '' || encodeQuantity === '' || encodeCondition === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /updateEquipment/{session}/{id}/{serialNo}/{name}/{equipmentType}/{quantity}/{condition}
        var url = '/service/updateEquipment/'
                + sessionId + '/'
                + encodeId + '/'
                + encodeSerialNo + '/'
                + encodeName + '/'
                + encodeEquipmentType + '/'
                + encodeQuantity + '/'
                + encodeCondition;

    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record updated to the database '
            }, {
                type: 'success'
            });

            window.location = "all_equipments.html";
        },
        error: function (data, status) {

            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record was not updated.'
            }, {
                type: 'danger'
            });
        }
    });
}

function loadDepartments() {
    // /getAllDepartments/{session}
    var url = '/service/getAllDepartments/' + sessionId;
    var html = '';
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            html += '<option disabled="" selected="">- Select Department -</option>';
            $.each(data, function (index, item) {
                html += '<option value="' + unescape(item.id) + '">' + unescape(item.name) + '</option>';
            });
            $('#department').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

function distributeEquipment() {
//    /addEquipmentDepartment/{session}/{equipment}/{department}/{quantity}
    var id = document.getElementById("id2").value;
    var department = document.getElementById("department").value;
    var quantity = document.getElementById("quantity").value;

    var encodeId = encodeURIComponent(id);
    var encodeDepartment = encodeURIComponent(department);
    var encodeQuantity = encodeURIComponent(quantity);


    if (encodeId === '' || encodeDepartment === '' || encodeQuantity === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /addEquipmentDepartment/{session}/{equipment}/{department}/{quantity}
        var url = '/service/addEquipmentDepartment/' + sessionId + '/' + encodeId + '/' + encodeDepartment + '/' + encodeQuantity;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record  was added to the database '
            }, {
                type: 'success'
            });
            window.location = "all_equipments.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record  was not added to the database '
            }, {
                type: 'danger'
            });

            console.log(data);
        }
    });
}

function stockEquipment() {
//    /updateEquipmentDepartmentStock/{session}/{id}/{quantity}
    var id = document.getElementById("id3").value;
    var quantity = document.getElementById("quantity2").value;

    var encodeId = encodeURIComponent(id);
    var encodeQuantity = encodeURIComponent(quantity);


    if (encodeId === '' || encodeQuantity === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /updateEquipmentDepartmentStock/{session}/{id}/{quantity}
        var url = '/service/updateEquipmentDepartmentStock/' + sessionId + '/' + encodeId + '/' + encodeQuantity;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record  was added to the database '
            }, {
                type: 'success'
            });
            window.location = "all_equipments.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record  was not added to the database '
            }, {
                type: 'danger'
            });

            console.log(data);
        }
    });
}