var sessionId;
var sessionDataObject;
var html = '';

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
        $('#personalInfo').hide();
    }
    ;
}

function getQueryParameter(parameterName) {
    var queryString = window.top.location.search.substring(1);
    var parameterName = parameterName + "=";
    if (queryString.length > 0) {
        begin = queryString.indexOf(parameterName);
        if (begin !== -1) {
            begin += parameterName.length;
            end = queryString.indexOf("&", begin);
            if (end === -1) {
                end = queryString.length
            }
            return unescape(queryString.substring(begin, end));
        }
    }
    return null;
}

function addRecordFunction() {
//    /addEquipment/{session}/{serialNo}/{name}/{equipmentType}/{quantity}/{condition}
    var serialNo = document.getElementById("serialNo").value;
    var name = document.getElementById("name").value;
    var equipmentType = document.getElementById("equipmentType").value;
    var quantity = document.getElementById("quantity").value;
    var condition = document.getElementById("condition").value;

    var encodeSerialNo = encodeURIComponent(serialNo);
    var encodeName = encodeURIComponent(name);
    var encodeEquipmentType = encodeURIComponent(equipmentType);
    var encodeQuantity = encodeURIComponent(quantity);
    var encodeCondition = encodeURIComponent(condition);


    if (encodeSerialNo === '' || encodeName === '' || encodeEquipmentType === '' || encodeQuantity === '' 
        || encodeCondition === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    }else
        // /addEquipment/{session}/{serialNo}/{name}/{equipmentType}/{quantity}/{condition}
        var url = '/service/addEquipment/' + sessionId + '/' + encodeSerialNo + '/' + encodeName + '/' + encodeEquipmentType
     + '/' + encodeQuantity + '/' + encodeCondition;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record  was added to the database '
            }, {
                type: 'success'
            });
            window.location = "all_equipments.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record  was not added to the database '
            }, {
                type: 'danger'
            });

            console.log(data);
        }
    });
}

function showPersonalInfo() {
    $('#personalInfo').show();
}