var sessionId;
var sessionDataObject;
var html = '';

function initForm() {
    if (sessionStorage.length > 0) {
        sessionDataObject = JSON.parse(sessionStorage.sessionId);
        sessionId = sessionDataObject.id;
    }
    ;

    if (sessionId === null) {
        window.location = "index.html";
    }

    if (sessionId !== null) {
        loadLoggedInUser();
        loadEmployees();
        loadEquipments();
        $('#personalInfo').hide();
    }
    ;
}

function getQueryParameter(parameterName) {
    var queryString = window.top.location.search.substring(1);
    var parameterName = parameterName + "=";
    if (queryString.length > 0) {
        begin = queryString.indexOf(parameterName);
        if (begin !== -1) {
            begin += parameterName.length;
            end = queryString.indexOf("&", begin);
            if (end === -1) {
                end = queryString.length
            }
            return unescape(queryString.substring(begin, end));
        }
    }
    return null;
}

function loadEmployees() {
    // /getAllEmployees/{session}
    var url = '/service/getAllEmployees/' + sessionId;
    var html = '';
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            html += '<option disabled="" selected="">- Select Employee -</option>';
            $.each(data, function (index, item) {
                html += '<option value="' + unescape(item.id) + '">' + unescape(item.fullnames) + '</option>';
            });
            $('#employee').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

function loadEquipments() {
    // /getAllEquipments/{session}
    var url = '/service/getAllEquipments/' + sessionId;
    var html = '';
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            html += '<option disabled="" selected="">- Select Equipment -</option>';
            $.each(data, function (index, item) {
                html += '<option value="' + unescape(item.id) + '">' + unescape(item.name) + '</option>';
            });
            $('#equipment').html(html);
        },
        error: function (data, status) {
            if (data.status === 400) {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            } else {
                $.notify({
                    title: '<strong>ERROR:</strong>',
                    message: 'Unable to load the record list'
                }, {
                    type: 'danger'
                });
            }
        }
    });
}

function addRecordFunction() {
//    /addFault/{session}/{employee}/{equipment}/{comments}/{priority}/{dateReported}
    var employee = document.getElementById("employee").value;
    var equipment = document.getElementById("equipment").value;
    var comments = document.getElementById("comments").value;
    var priority = document.getElementById("priority").value;
    var dateReported = document.getElementById("dateReported").value;

    var encodeEmployee = encodeURIComponent(employee);
    var encodeEquipment = encodeURIComponent(equipment);
    var encodeComments = encodeURIComponent(comments);
    var encodePriority = encodeURIComponent(priority);
    var encodeDateReported = encodeURIComponent(dateReported);


    if (encodeEmployee === '' || encodeEquipment === '' || encodeComments === '' || encodePriority === ''
            || encodeDateReported === '') {
        $.notify({
            title: '<strong>Error:</strong>',
            message: 'Make sure you have provided the fields in the form!'
        }, {
            type: 'danger'
        });


    } else
        // /addFault/{session}/{employee}/{equipment}/{comments}/{priority}/{dateReported}
        var url = '/service/addFault/' + sessionId + '/' + encodeEmployee + '/' + encodeEquipment + '/' + encodeComments
                + '/' + encodePriority + '/' + encodeDateReported;
    console.log(url);
    $.ajax({
        type: "POST",
        url: url,
        data: param = "",
        dataType: 'json',
        success: function (data, status) {
            $.notify({
                title: '<strong>SUCCESS:</strong>',
                message: 'Record  was added to the database '
            }, {
                type: 'success'
            });
            window.location = "all_faults.html";
        },
        error: function (data, status) {
            $.notify({
                title: '<strong>ERROR:</strong>',
                message: 'Record  was not added to the database '
            }, {
                type: 'danger'
            });

            console.log(data);
        }
    });
}

function showPersonalInfo() {
    $('#personalInfo').show();
}